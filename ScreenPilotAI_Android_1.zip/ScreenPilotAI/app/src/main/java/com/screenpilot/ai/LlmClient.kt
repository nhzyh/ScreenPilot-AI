package com.screenpilot.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** 调用兼容 OpenAI Chat Completions 格式的接口。 */
object LlmClient {
    fun chat(base: String, key: String, model: String, messages: JSONArray): String {
        var url = base.trim().trimEnd('/')
        if (!url.endsWith("/chat/completions")) url += "/chat/completions"
        require(url.startsWith("https://")) { "API 地址必须以 https:// 开头" }

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.2)
            .toString()

        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val status = c.responseCode
        val stream = if (status in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (status !in 200..299) throw RuntimeException("接口返回 HTTP $status")

        return JSONObject(text)
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .optString("content", "")
    }
}
