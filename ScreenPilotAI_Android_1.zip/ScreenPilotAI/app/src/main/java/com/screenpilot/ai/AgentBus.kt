package com.screenpilot.ai

/** 把任务进度从后台线程传给网页界面。 */
object AgentBus {
    @Volatile
    var listener: ((String) -> Unit)? = null

    fun send(message: String) {
        listener?.invoke(message)
    }
}
