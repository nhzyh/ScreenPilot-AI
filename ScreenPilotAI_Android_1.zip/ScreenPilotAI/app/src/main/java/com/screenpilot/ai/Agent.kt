package com.screenpilot.ai

import org.json.JSONArray
import org.json.JSONObject

/** 操控手机的循环：读屏幕 → 问 AI → 执行动作 → 再读屏幕。 */
object Agent {
    @Volatile
    var running = false

    @Volatile
    var cancelled = false

    private const val MAX_STEPS = 20
    private const val MAX_SENDS = 3

    private val SENSITIVE = listOf(
        "支付", "付款", "转账", "汇款", "删除", "清空", "发送", "提交订单", "立即购买",
        "确认购买", "下单", "卸载", "格式化", "退出登录", "注销", "授权", "确认支付",
        "发布", "发表", "切换账号", "绑定", "解绑", "充值", "红包", "提现", "打赏"
    )

    private val SYSTEM = """
你是一个 Android 手机操作助手，通过无障碍服务帮用户完成任务。
每一步你会收到当前屏幕的元素列表，格式：[编号] 类型 "文字" 标记。
你只能返回一个 JSON 对象，不要输出其他文字：
{"thought":"一句话说明","action":"动作","index":编号,"text":"文字","direction":"down或up","app":"应用名","message":"文字","risk":false}
action 取值：
- click：点击元素，需要 index
- input：向输入框输入文字，需要 index 和 text
- scroll：滚动，需要 direction（down 表示向下浏览更多内容）
- back：返回；home：回到桌面
- open_app：按名称打开应用，需要 app
- wait：等待页面加载
- finish：任务完成，message 写结果
- ask：需要用户提供信息或亲自操作（如登录、输入密码、验证码），message 写明需要什么
规则：
1. 编号只在当前这一屏有效，每次都以最新屏幕为准。
2. 不要输入或猜测密码、验证码、银行卡号；遇到这类步骤用 ask。
3. 涉及付款、转账、删除、发送消息、下单、授权等不可逆或有风险的点击，必须把 risk 设为 true。
4. 找不到目标时先 scroll 或 back，不要重复同样的动作。
5. 能完成就尽快 finish，不要多做用户没要求的事。
6. 微信、QQ 等聊天应用：先用搜索或通讯录找到联系人，确认聊天页顶部的名字与目标一致后再输入；输入完点击“发送”，发送后立即 finish，不要重复发送。
7. 要发送或发布的文字必须与用户给出的内容完全一致，不要自行改写或添加。
8. 每次任务最多发送 3 条消息或动态；不要群发，不要给陌生人发消息；不要读出或转述与任务无关的聊天内容。
""".trimIndent()

    fun stop() {
        cancelled = true
        ScreenPilotService.instance?.cancelPending()
    }

    fun start(api: String, key: String, model: String, task: String, auto: Boolean): String {
        if (running) return "busy"
        val svc = ScreenPilotService.instance ?: return "service_off"
        running = true
        cancelled = false
        Thread { runTask(svc, api, key, model, task, auto) }.start()
        return "ok"
    }

    private fun msg(role: String, content: String): JSONObject =
        JSONObject().put("role", role).put("content", content)

    private fun isSensitive(label: String): Boolean =
        label.isNotBlank() && SENSITIVE.any { label.contains(it) }

    private fun parseJson(t: String): JSONObject? {
        val a = t.indexOf('{')
        val b = t.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try {
            JSONObject(t.substring(a, b + 1))
        } catch (e: Exception) {
            null
        }
    }

    /** 只保留最近两屏的完整内容，节省 token。 */
    private fun trimOldScreens(msgs: JSONArray) {
        val idxs = ArrayList<Int>()
        for (i in 0 until msgs.length()) {
            val m = msgs.getJSONObject(i)
            if (m.getString("role") == "user" && m.getString("content").contains("【当前屏幕】")) {
                idxs.add(i)
            }
        }
        if (idxs.size > 2) {
            for (k in 0 until idxs.size - 2) {
                msgs.getJSONObject(idxs[k]).put("content", "（旧屏幕已省略）")
            }
        }
    }

    private fun perform(svc: ScreenPilotService, action: String, index: Int, act: JSONObject): String {
        return when (action) {
            "click" -> if (svc.click(index)) "ok" else "点击失败，编号可能已失效"
            "input" -> svc.input(index, act.optString("text"))
            "scroll" -> if (svc.scroll(act.optString("direction") != "up")) "ok" else "滚动失败"
            "back" -> {
                svc.goBack()
                "ok"
            }
            "home" -> {
                svc.goHome()
                "ok"
            }
            "open_app" -> if (svc.openApp(act.optString("app"))) "ok" else "找不到或无法打开该应用，请从桌面点击图标"
            "wait" -> "ok"
            else -> "未知动作"
        }
    }

    private fun runTask(
        svc: ScreenPilotService,
        api: String,
        key: String,
        model: String,
        task: String,
        auto: Boolean
    ) {
        val msgs = JSONArray()
        msgs.put(msg("system", SYSTEM))
        msgs.put(msg("user", "用户任务：$task"))
        val modeText = if (auto) "自动操作" else "逐步确认"
        AgentBus.send("#new:📱 开始执行：$task\n模式：$modeText")

        var lastResult = "无"
        var lastAction = ""
        var repeat = 0
        var parseFails = 0
        var finished = false
        var step = 0
        var lastTyped = ""
        var sends = 0

        try {
            svc.showBar("ScreenPilot：准备中…")
            svc.showPhone()
            svc.goHome()
            Thread.sleep(1200)

            while (step < MAX_STEPS && !cancelled && !finished) {
                step++
                val screen = svc.readScreen()
                AgentBus.send("#screen:" + svc.snapshotJson())
                svc.updatePreview()
                msgs.put(msg("user", "上一步结果：$lastResult\n【当前屏幕】\n" + screen.take(3500)))
                trimOldScreens(msgs)
                svc.showBar("第 $step 步：思考中…")

                val reply = LlmClient.chat(api, key, model, msgs)
                msgs.put(msg("assistant", reply))
                if (cancelled) break

                val act = parseJson(reply)
                if (act == null) {
                    parseFails++
                    if (parseFails >= 2) {
                        AgentBus.send("⚠️ AI 的返回格式不对，已停止")
                        break
                    }
                    lastResult = "你的回复不是合法 JSON，请只返回一个 JSON 对象"
                    continue
                }

                val action = act.optString("action")
                val thought = act.optString("thought")
                val index = act.optInt("index", -1)
                val label = if (index >= 0) svc.labelOf(index) else ""

                val sig = act.toString()
                if (sig == lastAction) repeat++ else repeat = 0
                lastAction = sig
                if (repeat >= 2) {
                    AgentBus.send("⚠️ AI 在重复同一个动作，已停止")
                    break
                }

                if (action == "finish") {
                    AgentBus.send("✅ " + act.optString("message", "任务完成"))
                    finished = true
                    continue
                }
                if (action == "ask") {
                    AgentBus.send("❓ " + act.optString("message") + "\n（任务已暂停，处理好后请重新下达任务）")
                    finished = true
                    continue
                }

                val dir = if (act.optString("direction") == "up") "上" else "下"
                val desc = when (action) {
                    "click" -> "点击 [$index]「$label」"
                    "input" -> "在 [$index] 输入「" + act.optString("text") + "」"
                    "scroll" -> "向${dir}滚动"
                    "back" -> "返回"
                    "home" -> "回到桌面"
                    "open_app" -> "打开应用「" + act.optString("app") + "」"
                    "wait" -> "等待页面加载"
                    else -> ""
                }
                if (desc.isEmpty()) {
                    lastResult = "未知动作 $action"
                    continue
                }

                val risky = act.optBoolean("risk", false) || isSensitive(label)
                val isSend = risky && (label.contains("发送") || label.contains("发布") || label.contains("发表"))
                if (isSend) {
                    sends++
                    if (sends > MAX_SENDS) {
                        AgentBus.send("⚠️ 单次任务最多发送 $MAX_SENDS 条，已停止")
                        break
                    }
                }
                svc.highlightPreview(if (action == "click" || action == "input") index else -1)
                AgentBus.send("#hl:" + (if (action == "click" || action == "input") index else -1) + "|" + desc)
                AgentBus.send("第 $step 步：$thought\n→ $desc")

                if (!auto || risky) {
                    svc.showBar("等待你确认…")
                    val prefix = if (risky) "⚠️ 敏感操作，请确认\n" else ""
                    val typed = if (risky && lastTyped.isNotEmpty()) "\n最近输入：「" + lastTyped.take(80) + "」" else ""
                    val ok = svc.confirm(prefix + "第 $step 步：" + desc + typed)
                    if (cancelled) break
                    if (!ok) {
                        AgentBus.send("⏹ 你取消了这一步，任务已停止")
                        break
                    }
                }

                svc.showBar("第 $step 步：$desc")
                lastResult = perform(svc, action, index, act)
                if (action == "input" && lastResult == "ok") lastTyped = act.optString("text")
                Thread.sleep(if (action == "wait") 2000L else 1500L)
            }

            if (!finished && !cancelled && step >= MAX_STEPS) {
                AgentBus.send("⚠️ 已达到最大步数（$MAX_STEPS），任务停止")
            }
        } catch (e: Exception) {
            AgentBus.send("❌ 出错：" + (e.message ?: e.javaClass.simpleName))
        } finally {
            if (cancelled) AgentBus.send("⏹ 已停止")
            running = false
            svc.hideBar()
        }
    }
}
