package com.screenpilot.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** 无障碍服务：读取屏幕、点击、输入、滚动，并显示停止按钮和确认窗口。 */
class ScreenPilotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenPilotService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private var bar: View? = null
    private var barText: TextView? = null
    private var confirmView: View? = null

    @Volatile
    private var confirmQueue: ArrayBlockingQueue<Boolean>? = null

    private val wm: WindowManager
        get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        Agent.stop()
        hideBar()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- 读取屏幕 ----------

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "（暂时读不到屏幕内容）"
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        sb.append("当前应用: ").append(root.packageName).append('\n')

        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 120) return
            if (!n.isVisibleToUser) return
            val text = n.text?.toString()?.take(60) ?: ""
            val desc = n.contentDescription?.toString()?.take(60) ?: ""
            val interactive = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
            if (text.isNotBlank() || desc.isNotBlank() || interactive) {
                val idx = list.size
                list.add(n)
                val kind = n.className?.toString()?.substringAfterLast('.') ?: "View"
                sb.append('[').append(idx).append("] ").append(kind)
                if (text.isNotBlank()) {
                    sb.append(" \"").append(text).append('"')
                } else if (desc.isNotBlank()) {
                    sb.append(" \"").append(desc).append('"')
                }
                if (n.isEditable) sb.append(" 可输入")
                if (n.isPassword) sb.append(" 密码框")
                if (n.isClickable) sb.append(" 可点击")
                if (n.isScrollable) sb.append(" 可滚动")
                if (n.isChecked) sb.append(" 已选中")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }

        walk(root)
        nodes = list
        return sb.toString()
    }

    /** 把最近一次读取的屏幕导出成简化线框（位置 + 文字），用于应用内“沙盒预览”。密码框文字不会导出。 */
    fun snapshotJson(): String {
        val dm = resources.displayMetrics
        val arr = org.json.JSONArray()
        var w = dm.widthPixels
        var h = dm.heightPixels
        for (n in nodes) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() <= 0 || r.height() <= 0) continue
            if (r.right > w) w = r.right
            if (r.bottom > h) h = r.bottom
        }
        nodes.forEachIndexed { i, n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() <= 0 || r.height() <= 0) {
                arr.put(org.json.JSONArray().put(0).put(0).put(0).put(0).put(0).put(""))
                return@forEachIndexed
            }
            val raw = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
            val t = if (n.isPassword) "••••" else raw.take(24)
            var flags = 0
            if (n.isClickable) flags = flags or 1
            if (n.isEditable) flags = flags or 2
            arr.put(
                org.json.JSONArray().put(maxOf(r.left, 0)).put(maxOf(r.top, 0)).put(r.right).put(r.bottom)
                    .put(flags).put(t)
            )
        }
        return org.json.JSONObject().put("w", w).put("h", h).put("n", arr).toString()
    }

    fun labelOf(idx: Int): String {
        val n = nodes.getOrNull(idx) ?: return ""
        val t = n.text?.toString()
        if (!t.isNullOrBlank()) return t
        return n.contentDescription?.toString() ?: ""
    }

    // ---------- 动作 ----------

    fun click(idx: Int): Boolean {
        val n = nodes.getOrNull(idx) ?: return false
        n.refresh()
        var t: AccessibilityNodeInfo? = n
        var depth = 0
        while (t != null && depth < 6) {
            if (t.isClickable && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            t = t.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        val p = Path()
        p.moveTo(r.centerX().toFloat(), r.centerY().toFloat())
        return gesture(p, 60)
    }

    fun input(idx: Int, text: String): String {
        val n = nodes.getOrNull(idx) ?: return "找不到编号 $idx"
        n.refresh()
        if (n.isPassword) return "这是密码框，不能代为输入，请让用户自己输入"
        val target = if (n.isEditable) n else findEditable(n)
        if (target == null) return "该元素不能输入文字"
        if (target.isPassword) return "这是密码框，不能代为输入，请让用户自己输入"
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok" else "输入失败"
    }

    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            val s = findScrollable(root)
            if (s != null) {
                val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (s.performAction(action)) return true
            }
        }
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val a = dm.heightPixels * 0.7f
        val b = dm.heightPixels * 0.3f
        val p = Path()
        if (down) {
            p.moveTo(x, a)
            p.lineTo(x, b)
        } else {
            p.moveTo(x, b)
            p.lineTo(x, a)
        }
        return gesture(p, 400)
    }

    fun goBack() {
        performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    fun goHome() {
        performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val q = name.trim().lowercase()
        if (q.isEmpty()) return false
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(launch)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (c.isEditable) return c
            val r = findEditable(c)
            if (r != null) return r
        }
        return null
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findScrollable(c)
            if (r != null) return r
        }
        return null
    }

    private fun gesture(path: Path, duration: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        val latch = CountDownLatch(1)
        var ok = false
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }
        if (!dispatchGesture(g, cb, null)) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    // ---------- 悬浮窗：状态条与确认窗 ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(14).toFloat()
        return d
    }

    private fun overlayParams(gravity: Int, yDp: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = gravity
        p.y = dp(yDp)
        return p
    }

    fun showBar(text: String) {
        main.post {
            if (bar == null) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(14), dp(8), dp(8), dp(8))
                row.background = roundBg(Color.parseColor("#E614233A"))
                val tv = TextView(this)
                tv.setTextColor(Color.WHITE)
                tv.textSize = 13f
                row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                val stop = Button(this)
                stop.text = "停止"
                stop.setOnClickListener { Agent.stop() }
                row.addView(stop)
                try {
                    wm.addView(row, overlayParams(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 40))
                    bar = row
                    barText = tv
                } catch (e: Exception) {
                    // 悬浮窗添加失败时，任务仍可继续，但没有停止按钮
                }
            }
            barText?.text = text
        }
    }

    fun hideBar() {
        hidePhone()
        main.post {
            val b = bar
            if (b != null) {
                try {
                    wm.removeView(b)
                } catch (e: Exception) {
                }
            }
            bar = null
            barText = null
        }
    }

    // ---------- 悬浮小手机：操作时显示在屏幕右下角 ----------

    private class PhoneView(ctx: Context, val d: Float) : View(ctx) {
        class Item(val l: Float, val t: Float, val r: Float, val b: Float, val flags: Int, val text: String)

        var sw = 1f
        var sh = 1f
        var items: List<Item> = emptyList()
        var hl = -1
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#33415C")
            textSize = d * 5f
        }
        private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = d * 3f
            color = Color.parseColor("#14233A")
        }

        override fun onDraw(c: Canvas) {
            val vw = width.toFloat()
            val vh = height.toFloat()
            val rad = d * 14f
            val whole = RectF(0f, 0f, vw, vh)
            c.drawRoundRect(whole, rad, rad, bg)
            val clip = android.graphics.Path()
            clip.addRoundRect(whole, rad, rad, android.graphics.Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            val sx = vw / sw
            val sy = vh / sh
            var hit: RectF? = null
            items.forEachIndexed { i, item ->
                val rc = RectF(item.l * sx, item.t * sy, item.r * sx, item.b * sy)
                if (rc.width() < 1f || rc.height() < 1f) return@forEachIndexed
                line.strokeWidth = d * 0.6f
                line.color = if (item.flags and 1 != 0) Color.parseColor("#802F6BFF") else Color.parseColor("#33789ABC")
                c.drawRect(rc, line)
                if (item.text.isNotEmpty() && rc.height() > d * 7f) {
                    c.save()
                    c.clipRect(rc)
                    c.drawText(item.text, rc.left + d, rc.top + d * 5.5f, txt)
                    c.restore()
                }
                if (i == hl) hit = rc
            }
            val h = hit
            if (h != null) {
                fill.color = Color.argb(70, 255, 59, 48)
                c.drawRect(h, fill)
                line.strokeWidth = d * 2f
                line.color = Color.parseColor("#FF3B30")
                c.drawRect(h, line)
            }
            c.restore()
            c.drawRoundRect(RectF(d * 1.5f, d * 1.5f, vw - d * 1.5f, vh - d * 1.5f), rad, rad, frame)
        }
    }

    private var phone: PhoneView? = null

    fun showPhone() {
        main.post {
            if (phone != null) return@post
            val v = PhoneView(this, resources.displayMetrics.density)
            val p = WindowManager.LayoutParams(
                dp(96),
                dp(208),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.BOTTOM or Gravity.END
            p.x = dp(12)
            p.y = dp(240)
            try {
                wm.addView(v, p)
                phone = v
            } catch (e: Exception) {
            }
        }
    }

    /** 用最近一次读到的屏幕刷新小手机。 */
    fun updatePreview() {
        val dm = resources.displayMetrics
        var w = dm.widthPixels
        var h = dm.heightPixels
        val rects = ArrayList<Rect>()
        for (n in nodes) {
            val r = Rect()
            n.getBoundsInScreen(r)
            rects.add(r)
            if (r.right > w) w = r.right
            if (r.bottom > h) h = r.bottom
        }
        val list = ArrayList<PhoneView.Item>()
        nodes.forEachIndexed { i, n ->
            val r = rects[i]
            val raw = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
            val t = if (n.isPassword) "••••" else raw.take(12)
            var flags = 0
            if (n.isClickable) flags = flags or 1
            if (n.isEditable) flags = flags or 2
            list.add(PhoneView.Item(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat(), flags, t))
        }
        val fw = w.toFloat()
        val fh = h.toFloat()
        main.post {
            val v = phone ?: return@post
            v.sw = fw
            v.sh = fh
            v.items = list
            v.hl = -1
            v.invalidate()
        }
    }

    fun highlightPreview(idx: Int) {
        main.post {
            val v = phone ?: return@post
            v.hl = idx
            v.invalidate()
        }
    }

    fun hidePhone() {
        main.post {
            val v = phone
            if (v != null) {
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }
            phone = null
        }
    }

    fun cancelPending() {
        confirmQueue?.offer(false)
    }

    /** 弹出确认窗并等待用户选择；超过 60 秒视为取消。 */
    fun confirm(message: String): Boolean {
        val q = ArrayBlockingQueue<Boolean>(1)
        confirmQueue = q
        main.post {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(16), dp(14), dp(16), dp(12))
            box.background = roundBg(Color.parseColor("#F514233A"))
            val tv = TextView(this)
            tv.text = message
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            box.addView(tv)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.END
            val no = Button(this)
            no.text = "取消"
            no.setOnClickListener { q.offer(false) }
            val yes = Button(this)
            yes.text = "允许"
            yes.setOnClickListener { q.offer(true) }
            row.addView(no)
            row.addView(yes)
            box.addView(row)
            try {
                wm.addView(box, overlayParams(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 90))
                confirmView = box
            } catch (e: Exception) {
                q.offer(false)
            }
        }
        val result = q.poll(60, TimeUnit.SECONDS) ?: false
        confirmQueue = null
        main.post {
            val v = confirmView
            if (v != null) {
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }
            confirmView = null
        }
        return result
    }
}
