package com.screenpilot.ai

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** 应用内更新：从 GitHub Releases 检查、下载并安装新版 APK。 */
object Updater {
    private const val REPO = "nhzyh/ScreenPilot-AI"

    @Volatile
    private var apkUrl: String? = null

    fun check(ctx: Context): JSONObject {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        val curCode = PackageInfoCompat.getLongVersionCode(info)
        val out = JSONObject().put("current", info.versionName ?: "")

        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "ScreenPilotAI")
        val status = c.responseCode
        if (status == 404) return out.put("state", "latest")
        if (status !in 200..299) return out.put("state", "error").put("message", "GitHub 返回 HTTP $status")

        val j = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        val tag = j.optString("tag_name", "")
        val code = tag.removePrefix("v").toLongOrNull() ?: return out.put("state", "latest")

        var url: String? = null
        val assets = j.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    url = a.optString("browser_download_url")
                    break
                }
            }
        }

        if (code > curCode && url != null) {
            apkUrl = url
            return out.put("state", "new")
                .put("latestName", j.optString("name", tag))
                .put("latestCode", code)
                .put("notes", j.optString("body", "").trim().take(120))
        }
        return out.put("state", "latest")
    }

    fun download(ctx: Context, onProgress: (Int) -> Unit): File {
        val url = apkUrl ?: throw IllegalStateException("更新地址未准备好，请重新检查更新")
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        val f = File(dir, "ScreenPilotAI.apk")

        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "ScreenPilotAI")
        val status = c.responseCode
        if (status !in 200..299) throw RuntimeException("下载失败 HTTP $status")
        val total = c.contentLengthLong

        c.inputStream.use { ins ->
            f.outputStream().use { outs ->
                val buf = ByteArray(32768)
                var sum = 0L
                var last = -1
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    outs.write(buf, 0, n)
                    sum += n
                    if (total > 0) {
                        val p = (sum * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            onProgress(p)
                        }
                    }
                }
            }
        }
        return f
    }

    /** 返回 ok 或 need_permission。 */
    fun install(ctx: Context, f: File): String {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            return "need_permission"
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "ok"
    }
}
