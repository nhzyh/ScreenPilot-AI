package com.screenpilot.ai

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var qrScanLauncher: ActivityResultLauncher<Intent>
    private lateinit var notifyPermissionLauncher: ActivityResultLauncher<String>
    private var agentListener: ((String) -> Unit)? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        qrScanLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data ?: return@registerForActivityResult
            val text = data.getStringExtra("text").orEmpty()
            val (ip, port, code) = parseQr(text)
            runOnUiThread {
                web.evaluateJavascript(
                    "window.__onQrScan && window.__onQrScan(${JSONObject.quote(ip)},$port,${JSONObject.quote(code)})",
                    null
                )
            }
        }
        notifyPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifyPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "mailto") {
                    startActivity(Intent(Intent.ACTION_SENDTO, u))
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        agentListener = { m ->
            runOnUiThread {
                web.evaluateJavascript("window.__onAgent(" + JSONObject.quote(m) + ")", null)
            }
        }
        AgentBus.addListener(agentListener!!)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun sendUpdate(o: JSONObject) {
        runOnUiThread {
            web.evaluateJavascript("window.__onUpdate(" + o.toString() + ")", null)
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasSecure() && ScreenPilotService.instance == null) ensureAccessibility()
    }

    private fun hasSecure(): Boolean =
        checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** 已通过无线调试授予“修改安全设置”权限后，App 可自己重新打开无障碍服务。 */
    private fun ensureAccessibility(): Boolean {
        if (!hasSecure()) return false
        return try {
            val cn = ComponentName(this, ScreenPilotService::class.java).flattenToString()
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!cur.split(':').any { it.equals(cn, true) }) {
                val nv = if (cur.isEmpty()) cn else "$cur:$cn"
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, nv)
            }
            Settings.Secure.putString(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, "1")
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onDestroy() {
        agentListener?.let { AgentBus.removeListener(it) }
        agentListener = null
        super.onDestroy()
    }

    private fun parseQr(text: String): Triple<String, Int, String> {
        val hostMatch = Regex("""(\d{1,3}(?:\.\d{1,3}){3}):(\d+)""").find(text)
        val ip = hostMatch?.groupValues?.getOrNull(1).orEmpty()
        val port = hostMatch?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
        val code = Regex("""\b\d{6}\b""").find(text)?.value.orEmpty()
        return Triple(ip, port, code)
    }

    inner class Bridge {
        /** 由网页调用：在原生层发起 HTTPS 请求，避开浏览器 CORS 限制。 */
        @JavascriptInterface
        fun request(id: String, url: String, key: String, body: String) {
            Thread {
                var status = 0
                var out = ""
                try {
                    if (!url.startsWith("https://")) throw IllegalArgumentException("仅支持 https:// 开头的 API 地址")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 20000
                    c.readTimeout = 120000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer $key")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    status = c.responseCode
                    val stream = if (status in 200..299) c.inputStream else c.errorStream
                    out = stream?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                } catch (e: Exception) {
                    status = 0
                    out = e.message ?: "网络错误"
                }
                val b64 = Base64.encodeToString(out.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                runOnUiThread {
                    web.evaluateJavascript("window.__onNative('$id',$status,'$b64')", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun serviceEnabled(): Boolean {
            if (ScreenPilotService.instance == null) ensureAccessibility()
            return ScreenPilotService.instance != null
        }

        private fun labRun(block: () -> String) {
            Thread {
                val r = try {
                    block()
                } catch (t: Throwable) {
                    "错误：" + t.javaClass.simpleName + "：" + (t.message ?: "")
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__onLab(" + JSONObject.quote(r) + ")", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun labPair(host: String, port: Int, code: String) {
            labRun { SandboxLab.pair(this@MainActivity, host, port, code) }
        }

        @JavascriptInterface
        fun labConnect(host: String, port: Int) {
            labRun { SandboxLab.connect(this@MainActivity, host, port) }
        }

        @JavascriptInterface
        fun labShell(cmd: String) {
            labRun { SandboxLab.shell(this@MainActivity, cmd) }
        }

        @JavascriptInterface
        fun labDisplays(): String {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            return dm.displays.joinToString("\n") { "id=" + it.displayId + " " + it.name + " " + it.width + "x" + it.height }
        }

        @JavascriptInterface
        fun hasSecure(): Boolean = this@MainActivity.hasSecure()

        @JavascriptInterface
        fun overlayEnabled(): Boolean = Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface
        fun scanQr() {
            val intent = Intent(this@MainActivity, QrScanActivity::class.java)
            qrScanLauncher.launch(intent)
        }

        @JavascriptInterface
        fun autoEnable(): Boolean = ensureAccessibility()

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                    try {
                        val details = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + packageName)
                        )
                        startActivity(details)
                    } catch (_: Exception) {
                        // 个别系统无法直接跳转；JS 层会提示用户手动进入无障碍。
                    }
                }
            }
        }

        @JavascriptInterface
        fun openWirelessDebug() {
            runOnUiThread {
                try {
                    startActivity(Intent("android.settings.WIRELESS_DEBUGGING"))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent("android.settings.DEVELOPMENT_SETTINGS"))
                    } catch (_: Exception) {
                        // 个别系统不支持直接跳转；页面保留手动路径说明。
                    }
                }
            }
        }

        /** 返回 ok / busy / service_off / bad_api */
        @JavascriptInterface
        fun startTask(api: String, key: String, model: String, task: String, auto: Boolean): String {
            if (!api.trim().startsWith("https://")) return "bad_api"
            return Agent.start(api, key, model, task, auto)
        }

        /** 网页把签到任务配置同步到本机，并注册每日定时提醒。 */
        @JavascriptInterface
        fun syncTasks(tasksJson: String) {
            TaskScheduler.saveTasks(this@MainActivity, tasksJson)
        }

        @JavascriptInterface
        fun appVersion(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun checkUpdate() {
            Thread {
                val o = try {
                    Updater.check(this@MainActivity)
                } catch (e: Exception) {
                    JSONObject().put("state", "error").put("message", e.message ?: "网络错误")
                }
                sendUpdate(o)
            }.start()
        }

        @JavascriptInterface
        fun installUpdate() {
            Thread {
                try {
                    val f = Updater.download(this@MainActivity) { p ->
                        sendUpdate(JSONObject().put("state", "downloading").put("percent", p))
                    }
                    val r = Updater.install(this@MainActivity, f)
                    if (r == "need_permission") {
                        runOnUiThread {
                            startActivity(
                                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                    sendUpdate(JSONObject().put("state", if (r == "ok") "installing" else "need_permission"))
                } catch (e: Exception) {
                    sendUpdate(JSONObject().put("state", "error").put("message", e.message ?: "下载失败"))
                }
            }.start()
        }

        @JavascriptInterface
        fun stopTask() {
            Agent.stop()
        }
    }
}
