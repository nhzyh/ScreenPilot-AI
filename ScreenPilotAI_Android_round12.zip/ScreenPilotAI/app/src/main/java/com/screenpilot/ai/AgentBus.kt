package com.screenpilot.ai

import java.util.concurrent.CopyOnWriteArrayList

/** 把任务进度从后台线程传给网页界面或定时任务通知。 */
object AgentBus {
    private val listeners = CopyOnWriteArrayList<(String) -> Unit>()

    fun addListener(listener: (String) -> Unit) {
        listeners.addIfAbsent(listener)
    }

    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }

    fun send(message: String) {
        listeners.forEach { it.invoke(message) }
    }
}
