ScreenPilot AI - Android 项目 V1.5（开发版）

打开方式：
1. 安装 Android Studio（Koala 或更新版本）。
2. File → Open，选择本文件夹，等待 Gradle 同步完成。
3. 连接 Android 手机（开启 USB 调试）或使用模拟器，点击 Run 运行。
4. 导出安装包：Build → Build APK(s)。

主要功能：
- WebView 聊天界面，调用兼容 OpenAI Chat Completions 的 HTTPS API。
- Android 无障碍服务读取可访问的屏幕文字，并执行点击、输入、滚动、返回和打开应用。
- 操控任务从当前屏幕开始；支持逐步确认、自动模式和悬浮停止按钮。
- 从 GitHub Releases 检查并下载 APK 更新，安装仍需 Android 系统确认。

注意：
- 当前屏幕理解主要依赖 Android 无障碍节点，不是完整的视觉识屏；无法保证识别游戏画面、Canvas、自绘控件或图片按钮。
- 自动操作可能误判；付款、删除、发送、发布、授权等关键操作应由用户核对确认。
- 应用内更新要求 GitHub Release 的 tag 使用点分版本号（例如 v1.6），并附带同包名、同签名的 APK。
- 本项目没有提供静默安装能力；Android 系统会显示安装确认界面。
