package com.screenpilot.ai

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "mailto") {
                    startActivity(Intent(Intent.ACTION_SENDTO, u))
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        AgentBus.listener = { m ->
            runOnUiThread {
                web.evaluateJavascript("window.__onAgent(" + JSONObject.quote(m) + ")", null)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun sendUpdate(o: JSONObject) {
        runOnUiThread {
            web.evaluateJavascript("window.__onUpdate(" + o.toString() + ")", null)
        }
    }

    override fun onDestroy() {
        AgentBus.listener = null
        super.onDestroy()
    }

    inner class Bridge {
        /** 由网页调用：在原生层发起 HTTPS 请求，避开浏览器 CORS 限制。 */
        @JavascriptInterface
        fun request(id: String, url: String, key: String, body: String) {
            Thread {
                var status = 0
                var out = ""
                try {
                    if (!url.startsWith("https://")) throw IllegalArgumentException("仅支持 https:// 开头的 API 地址")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 20000
                    c.readTimeout = 120000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer $key")
                    c.outputStream.use { it.write(body.toByteArray()) }
                    status = c.responseCode
                    val stream = if (status in 200..299) c.inputStream else c.errorStream
                    out = stream?.bufferedReader()?.readText() ?: ""
                } catch (e: Exception) {
                    status = 0
                    out = e.message ?: "网络错误"
                }
                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                runOnUiThread {
                    web.evaluateJavascript("window.__onNative('$id',$status,'$b64')", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun serviceEnabled(): Boolean = ScreenPilotService.instance != null

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        /** 返回 ok / busy / service_off / bad_api */
        @JavascriptInterface
        fun startTask(api: String, key: String, model: String, task: String, auto: Boolean): String {
            if (!api.trim().startsWith("https://")) return "bad_api"
            return Agent.start(api, key, model, task, auto)
        }

        @JavascriptInterface
        fun appVersion(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun checkUpdate() {
            Thread {
                val o = try {
                    Updater.check(this@MainActivity)
                } catch (e: Exception) {
                    JSONObject().put("state", "error").put("message", e.message ?: "网络错误")
                }
                sendUpdate(o)
            }.start()
        }

        @JavascriptInterface
        fun installUpdate() {
            Thread {
                try {
                    val f = Updater.download(this@MainActivity) { p ->
                        sendUpdate(JSONObject().put("state", "downloading").put("percent", p))
                    }
                    val r = Updater.install(this@MainActivity, f)
                    if (r == "need_permission") {
                        runOnUiThread {
                            startActivity(
                                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName))
                            )
                        }
                    }
                    sendUpdate(JSONObject().put("state", if (r == "ok") "installing" else "need_permission"))
                } catch (e: Exception) {
                    sendUpdate(JSONObject().put("state", "error").put("message", e.message ?: "下载失败"))
                }
            }.start()
        }

        @JavascriptInterface
        fun stopTask() {
            Agent.stop()
        }
    }
}
