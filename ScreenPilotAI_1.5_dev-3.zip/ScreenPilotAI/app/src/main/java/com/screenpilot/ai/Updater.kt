package com.screenpilot.ai

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** 应用内更新：从 GitHub Releases 检查、下载并安装新版 APK。 */
object Updater {
    private const val REPO = "nhzyh/ScreenPilot-AI"

    @Volatile
    private var apkUrl: String? = null

    fun check(ctx: Context): JSONObject {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        val out = JSONObject().put("current", info.versionName ?: "")

        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "ScreenPilotAI")
        val status = c.responseCode
        if (status == 404) return out.put("state", "latest")
        if (status !in 200..299) return out.put("state", "error").put("message", "GitHub 返回 HTTP $status")

        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = j.optString("tag_name", "").trim()
        val latestVersion = tag.removePrefix("v").removePrefix("V")
        val currentVersion = (info.versionName ?: "0").removePrefix("v").removePrefix("V")
        if (!isNewerVersion(latestVersion, currentVersion)) return out.put("state", "latest")

        var url: String? = null
        val assets = j.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    url = a.optString("browser_download_url")
                    break
                }
            }
        }

        if (url != null) {
            apkUrl = url
            return out.put("state", "new")
                .put("latestName", j.optString("name", tag))
                .put("latestVersion", latestVersion)
                .put("notes", j.optString("body", "").trim().take(120))
        }
        return out.put("state", "latest")
    }

    /** 比较点分版本号，避免把 v1.5 错当成整数 1，与 versionCode 4 比较而漏更。 */
    private fun isNewerVersion(latest: String, current: String): Boolean {
        fun parts(v: String): List<Int>? {
            val core = v.substringBefore('-').substringBefore('+')
            if (core.isBlank() || !core.matches(Regex("\\d+(\\.\\d+)*"))) return null
            return core.split('.').map { it.toIntOrNull() ?: return null }
        }
        val a = parts(latest) ?: return false
        val b = parts(current) ?: return false
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun download(ctx: Context, onProgress: (Int) -> Unit): File {
        val url = apkUrl ?: throw IllegalStateException("请先检查更新")
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        val f = File(dir, "ScreenPilotAI.apk")

        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "ScreenPilotAI")
        val status = c.responseCode
        if (status !in 200..299) throw RuntimeException("下载失败 HTTP $status")
        val total = c.contentLengthLong

        c.inputStream.use { ins ->
            f.outputStream().use { outs ->
                val buf = ByteArray(32768)
                var sum = 0L
                var last = -1
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    outs.write(buf, 0, n)
                    sum += n
                    if (total > 0) {
                        val p = (sum * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            onProgress(p)
                        }
                    }
                }
            }
        }
        if (f.length() < 1024L) {
            f.delete()
            throw RuntimeException("下载文件异常：APK 文件过小")
        }
        f.inputStream().use { input ->
            val signature = ByteArray(2)
            if (input.read(signature) != 2 || signature[0] != 0x50.toByte() || signature[1] != 0x4B.toByte()) {
                f.delete()
                throw RuntimeException("下载文件不是有效的 APK 压缩包")
            }
        }
        return f
    }

    /** 返回 ok 或 need_permission。 */
    fun install(ctx: Context, f: File): String {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            return "need_permission"
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "ok"
    }
}
