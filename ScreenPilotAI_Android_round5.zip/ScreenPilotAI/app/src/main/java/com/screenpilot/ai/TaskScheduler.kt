package com.screenpilot.ai

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** 每日签到等定时任务：本机保存配置、到点广播、通知提醒并交给 Agent 执行。 */
object TaskScheduler {
    private const val PREFS = "screenpilot_tasks"
    private const val KEY_TASKS = "tasks"
    private const val CHANNEL_ID = "screenpilot_tasks"

    fun saveTasks(context: Context, json: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TASKS, json).apply()
        rescheduleAll(context)
    }

    fun rescheduleAll(context: Context) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TASKS, "") ?: ""
        if (raw.isEmpty()) return
        val arr = try {
            JSONArray(raw)
        } catch (e: Exception) {
            return
        }
        for (i in 0 until arr.length()) {
            val task = arr.optJSONObject(i) ?: continue
            if (!task.optBoolean("enabled", false)) continue
            schedule(context, task)
        }
    }

    fun schedule(context: Context, task: JSONObject) {
        if (!task.optBoolean("enabled", false)) return
        val time = task.optString("time", "")
        if (!time.matches(Regex("""\d{2}:\d{2}"""))) return

        val intent = Intent(context, TaskReceiver::class.java)
        intent.putExtra("task", task.toString())
        val pi = PendingIntent.getBroadcast(
            context,
            task.optString("id", "").hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, nextTrigger(time), AlarmManager.INTERVAL_DAY, pi)
    }

    private fun nextTrigger(time: String): Long {
        val parts = time.split(":")
        val hh = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val mm = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hh)
        cal.set(Calendar.MINUTE, mm)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "定时任务提醒",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "签到、定时任务执行前后的通知提醒" }
        nm.createNotificationChannel(channel)
    }

    fun notify(context: Context, title: String, body: String) {
        ensureChannel(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val contentPi = PendingIntent.getActivity(
            context,
            title.hashCode(),
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(android.app.Notification.BigTextStyle().bigText(body))
            .setContentIntent(contentPi)
            .setAutoCancel(true)
            .build()
        nm.notify((title + body).hashCode(), n)
    }
}

class TaskReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val raw = intent.getStringExtra("task") ?: return
        val task = try {
            JSONObject(raw)
        } catch (e: Exception) {
            TaskScheduler.notify(context, "签到任务", "任务配置损坏，未能启动")
            return
        }
        if (!task.optBoolean("enabled", false)) return
        val app = task.optString("app", "")
        val button = task.optString("button", "").trim()
        val api = task.optString("api", "")
        val key = task.optString("key", "")
        val model = task.optString("model", "")
        val prompt = buildPrompt(app, button)

        TaskScheduler.notify(context, "签到任务", "准备为「$app」执行签到")
        val finishListener: (String) -> Unit = { message ->
            if (message.startsWith("✅") || message.startsWith("❌") ||
                message.startsWith("❓") || message.startsWith("⏹") || message.startsWith("⚠️")
            ) {
                AgentBus.removeListener(finishListener)
                TaskScheduler.notify(context, "签到结果", message)
            }
        }
        AgentBus.addListener(finishListener)

        if (api.isEmpty() || key.isEmpty() || model.isEmpty()) {
            AgentBus.removeListener(finishListener)
            TaskScheduler.notify(context, "签到任务", "API 设置缺失，请先在 App 内保存接口地址、Key 和模型")
            return
        }
        val result = Agent.start(api, key, model, prompt, true)
        if (result != "ok") {
            AgentBus.removeListener(finishListener)
            val reason = when (result) {
                "busy" -> "上一个任务还在执行，本次签到未启动"
                "service_off" -> "无障碍服务未开启，请先在 App 内授权"
                "bad_api" -> "API 地址不是 https:// 开头"
                else -> "任务未启动：$result"
            }
            TaskScheduler.notify(context, "签到任务", reason)
        }
    }

    private fun buildPrompt(app: String, button: String): String {
        val buttonText = if (button.isBlank()) "" else "，优先点击文字为「$button」的签到按钮"
        return "在「$app」里完成每日签到。流程：打开 $app，找到签到入口$buttonText，点击签到；如果页面显示已经签到、签到成功或领取成功，就结束。不要支付、不要下单、不要提交订单；遇到付款、充值、密码、验证码步骤时停下并提示用户亲自处理。"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) TaskScheduler.rescheduleAll(context)
    }
}
