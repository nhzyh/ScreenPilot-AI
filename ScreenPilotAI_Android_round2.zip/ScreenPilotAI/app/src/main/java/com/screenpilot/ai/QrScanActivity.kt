package com.screenpilot.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Camera
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.Result
import com.google.zxing.common.HybridBinarizer

/** 扫码配对页面：识别二维码文本，返回给 MainActivity 解析地址、端口和配对码。 */
class QrScanActivity : Activity() {

    private var camera: Camera? = null
    private val reader = MultiFormatReader().apply {
        setHints(mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)))
    }

    private val previewCallback = Camera.PreviewCallback { data, cam ->
        val size = cam.parameters.previewSize
        val source = PlanarYUVLuminanceSource(
            data, size.width, size.height, 0, 0, size.width, size.height, false
        )
        val bitmap = BinaryBitmap(HybridBinarizer(source))
        val result: Result? = try {
            reader.decodeWithState(bitmap)
        } catch (e: Exception) {
            null
        }
        if (result != null) {
            runOnUiThread { finishWith(result.text) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val surface = SurfaceView(this)
        setContentView(surface)

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
        }

        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                camera = Camera.open()?.apply {
                    setPreviewDisplay(holder)
                    setPreviewCallback(previewCallback)
                    startPreview()
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                camera?.stopPreview()
                camera?.release()
                camera = null
            }
        })
    }

    override fun onPause() {
        super.onPause()
        camera?.stopPreview()
        camera?.release()
        camera = null
    }

    private fun finishWith(text: String) {
        val data = Intent().putExtra("text", text)
        setResult(RESULT_OK, data)
        finish()
    }

    companion object {
        private const val REQUEST_CAMERA = 101
    }
}
