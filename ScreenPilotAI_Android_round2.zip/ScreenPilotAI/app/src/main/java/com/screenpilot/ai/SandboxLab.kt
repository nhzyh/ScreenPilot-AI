package com.screenpilot.ai

import android.content.Context
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.conscrypt.Conscrypt
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Security
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** 应用内无线调试（ADB）连接：密钥和证书保存在应用私有目录，只配对一次。 */
class LabAdb private constructor(
    private val priv: PrivateKey,
    private val cert: Certificate
) : AbsAdbConnectionManager() {

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "ScreenPilotAI"

    companion object {
        @Volatile
        private var inst: LabAdb? = null

        fun get(ctx: Context): LabAdb = inst ?: synchronized(this) {
            inst ?: build(ctx.applicationContext).also { inst = it }
        }

        private fun build(ctx: Context): LabAdb {
            Security.insertProviderAt(Conscrypt.newProvider(), 1)
            val kf = File(ctx.filesDir, "adb_key.pk8")
            val cf = File(ctx.filesDir, "adb_cert.der")
            val priv: PrivateKey
            val cert: Certificate
            if (kf.exists() && cf.exists()) {
                priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            } else {
                val gen = KeyPairGenerator.getInstance("RSA")
                gen.initialize(2048)
                val kp = gen.generateKeyPair()
                val name = X500Name("CN=ScreenPilotAI")
                val now = System.currentTimeMillis()
                val builder = JcaX509v3CertificateBuilder(
                    name, BigInteger.valueOf(now),
                    Date(now - 86400000L), Date(now + 3650L * 86400000L),
                    name, kp.public
                )
                val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
                cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
                priv = kp.private
                kf.writeBytes(priv.encoded)
                cf.writeBytes(cert.encoded)
            }
            return LabAdb(priv, cert)
        }
    }
}

object SandboxLab {
    fun pair(ctx: Context, host: String, port: Int, code: String): String {
        val ok = LabAdb.get(ctx).pair(host, port, code)
        return if (ok) "配对成功。请回到无线调试页面，记下“IP 地址和端口”，再点“连接”。" else "配对失败：请确认配对码弹窗还开着，且地址、端口、配对码都没填错。"
    }

    fun connect(ctx: Context, host: String, port: Int): String {
        val ok = LabAdb.get(ctx).connect(host, port)
        if (!ok) return "连接失败。请确认地址和端口来自无线调试主页面（不是配对弹窗）。"
        return "连接成功。\n" + shell(ctx, "getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk")
    }

    fun shell(ctx: Context, cmd: String): String {
        val mgr = LabAdb.get(ctx)
        val stream = mgr.openStream("shell:$cmd")
        try {
            val text = stream.openInputStream().readBytes().toString(Charsets.UTF_8).trim()
            return if (text.isEmpty()) "（无输出，命令已执行）" else text
        } finally {
            try {
                stream.close()
            } catch (e: Exception) {
            }
        }
    }
}
