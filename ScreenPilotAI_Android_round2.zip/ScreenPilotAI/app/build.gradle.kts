plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.screenpilot.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.screenpilot.ai"
        minSdk = 30
        targetSdk = 34
        versionCode = 12
        versionName = "2.7-test"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("com.github.MuntashirAkon:libadb-android:master-SNAPSHOT")
    implementation("org.conscrypt:conscrypt-android:2.5.3")
    implementation("org.bouncycastle:bcpkix-jdk15to18:1.81")
    implementation("com.google.zxing:core:3.5.3")
}
