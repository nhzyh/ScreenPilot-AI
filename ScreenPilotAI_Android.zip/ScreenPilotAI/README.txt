ScreenPilot AI - Android 项目 V1.1（试用版）

打开方式：
1. 安装 Android Studio（Koala 或更新版本）。
2. File → Open，选择本文件夹，等待 Gradle 同步完成。
3. 连接 Android 手机（开启 USB 调试）或使用模拟器，点击 Run 运行。
4. 想导出安装包：Build → Build APK(s)。

说明：
- 页面文件在 app/src/main/assets/index.html，改页面直接改这个文件。
- 聊天请求由原生层发出，不受浏览器 CORS 限制；API 地址必须是 https:// 开头。
- 目前不包含手机控制功能；下一阶段将加入无障碍服务。
