package com.screenpilot.ai

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "mailto") {
                    startActivity(Intent(Intent.ACTION_SENDTO, u))
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    /** 由网页调用：在原生层发起 HTTPS 请求，避开浏览器 CORS 限制。 */
    inner class Bridge {
        @JavascriptInterface
        fun request(id: String, url: String, key: String, body: String) {
            Thread {
                var status = 0
                var out = ""
                try {
                    if (!url.startsWith("https://")) throw IllegalArgumentException("仅支持 https:// 开头的 API 地址")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 20000
                    c.readTimeout = 120000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer $key")
                    c.outputStream.use { it.write(body.toByteArray()) }
                    status = c.responseCode
                    val stream = if (status in 200..299) c.inputStream else c.errorStream
                    out = stream?.bufferedReader()?.readText() ?: ""
                } catch (e: Exception) {
                    status = 0
                    out = e.message ?: "网络错误"
                }
                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                runOnUiThread {
                    web.evaluateJavascript("window.__onNative('$id',$status,'$b64')", null)
                }
            }.start()
        }
    }
}
